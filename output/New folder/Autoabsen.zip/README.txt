1. Letakkan folder 'chromedriver_win32' di C:/
2. Tekan tombol start -> ketik "path" -> klik "edit system and environment variables"
3. klik environment variables
4. pada kotak system variables, klik 1x pada "Path" lalu tekan edit
5. tekan new, lalu ketikkan "C:\chromedriver_win32" lalu tekan ok

6. buka file main.exe
7. penuhi instruksi

jika ingin merubah jadwal, silahkan edit pada file jadwal.csv